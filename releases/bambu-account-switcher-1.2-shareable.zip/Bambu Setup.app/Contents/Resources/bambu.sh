#!/bin/bash
# Private, local-only Bambu Studio profile switcher for macOS.
# It does not upload, share, or otherwise expose account data.
set -euo pipefail

AS="$HOME/Library/Application Support"
LINK="$AS/BambuStudio"
ROOT="$AS/BambuStudio.profiles"
SESS="$ROOT/.sessions"
HS="$HOME/Library/HTTPStorages"
APP_PATH="${BAMBU_STUDIO_APP:-/Applications/BambuStudio.app}"
SESS_ITEMS=("com.bambulab.bambu-studio.binarycookies" "com.bambulab.bambu-studio")

die() { echo "Error: $*" >&2; exit 1; }
valid_profile() {
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._\ -]{0,63}$ ]] && [[ "$1" != .* ]] && [[ "$1" != *".."* ]]
}
require_profile() { valid_profile "$1" || die "Profile names use letters, numbers, spaces, dot, underscore, or dash and cannot begin with a dot."; }
list_profiles() { [ -d "$ROOT" ] && find "$ROOT" -mindepth 1 -maxdepth 1 -type d -not -name .sessions -exec basename {} \; | LC_ALL=C sort || true; }
current() { [ -L "$LINK" ] && basename "$(readlink "$LINK")" || echo "(none)"; }
preflight() {
  [ -d "$AS" ] || die "Missing Application Support directory: $AS"
  [ -d "$APP_PATH" ] || die "Bambu Studio was not found at $APP_PATH. Install it or set BAMBU_STUDIO_APP to its .app path."
  mkdir -p "$ROOT" "$SESS" "$HS"
  [ ! -e "$LINK" ] || [ -L "$LINK" ] || die "BambuStudio is not yet managed. Run setup first."
}
quit_bambu() {
  if pgrep -f 'MacOS/BambuStudio' >/dev/null 2>&1; then
    echo "Requesting Bambu Studio to quit. Save any open work first."
    osascript -e 'tell application "BambuStudio" to quit' >/dev/null 2>&1 || die "Could not ask Bambu Studio to quit. Quit it manually, then retry."
    local n=0
    while pgrep -f 'MacOS/BambuStudio' >/dev/null 2>&1; do
      n=$((n + 1))
      [ "$n" -lt 30 ] || die "Bambu Studio is still open after 30 seconds. Nothing was changed; quit it manually and retry."
      sleep 1
    done
  fi
}
copy_item() { if [ -e "$1" ]; then cp -R "$1" "$2"; fi; }
save_session() {
  local p="$1" tmp="$SESS/.${1}.new.$$" old="$SESS/.${1}.old.$$"
  [ "$p" = "(none)" ] && return 0
  require_profile "$p"; rm -rf "$tmp"; mkdir -p "$tmp"
  for it in "${SESS_ITEMS[@]}"; do copy_item "$HS/$it" "$tmp/" || { rm -rf "$tmp"; die "Could not back up the current login session."; }; done
  [ -e "$SESS/$p" ] && mv "$SESS/$p" "$old"
  if mv "$tmp" "$SESS/$p"; then rm -rf "$old"; else [ -e "$old" ] && mv "$old" "$SESS/$p"; die "Could not save the current login session."; fi
}
restore_session() {
  local p="$1" stage="$HS/.bambu-switch-new.$$" backup="$HS/.bambu-switch-old.$$"
  require_profile "$p"; rm -rf "$stage" "$backup"; mkdir -p "$stage" "$backup"
  if [ -d "$SESS/$p" ]; then for it in "${SESS_ITEMS[@]}"; do copy_item "$SESS/$p/$it" "$stage/" || { rm -rf "$stage" "$backup"; die "Could not prepare the selected profile's login session."; }; done; fi
  for it in "${SESS_ITEMS[@]}"; do [ -e "$HS/$it" ] && mv "$HS/$it" "$backup/"; done
  local staged
  for staged in "$stage"/*; do
    [ -e "$staged" ] || continue
    if ! mv "$staged" "$HS/"; then
      rm -rf "$stage"
      for staged in "$backup"/*; do [ -e "$staged" ] && mv "$staged" "$HS/" || true; done
      die "Session replacement failed and the previous session was restored."
    fi
  done
  rm -rf "$stage" "$backup"
}
switch_to() {
  local p="$1" cur target_new target_old
  require_profile "$p"; preflight
  [ -d "$ROOT/$p" ] || die "No such profile: $p"
  cur="$(current)"; [ "$cur" = "$p" ] && { echo "Already using $p."; open -a "$APP_PATH"; exit 0; }
  quit_bambu
  [ "$cur" != "(none)" ] && [ -d "$ROOT/$cur" ] && save_session "$cur"
  target_new="$AS/.BambuStudio.new.$$"; target_old="$AS/.BambuStudio.old.$$"
  ln -s "$ROOT/$p" "$target_new" || die "Could not prepare profile switch."
  [ -L "$LINK" ] && mv "$LINK" "$target_old"
  if mv "$target_new" "$LINK"; then
    if restore_session "$p"; then rm -f "$target_old"; else rm -f "$LINK"; [ -e "$target_old" ] && mv "$target_old" "$LINK"; die "Profile link was restored after session failure."; fi
  else rm -f "$target_new"; [ -e "$target_old" ] && mv "$target_old" "$LINK"; die "Could not switch profile; previous profile remains active."; fi
  open -a "$APP_PATH"; echo "Now running Bambu Studio as: $p"
}
make_dock_app() {
  local p="$1" appdir="$HOME/Applications" app icon_source identifier
  require_profile "$p"; mkdir -p "$appdir"
  icon_source="$HOME/.local/share/bambu-profile-switcher/bambu.icns"
  [ -f "$icon_source" ] || die "The Bambu launcher icon is missing. Re-run Bambu Setup.app before making profile launchers."
  identifier="$(printf '%s' "$p" | LC_ALL=C tr '[:upper:] ' '[:lower:]-' | tr -cd 'a-z0-9.-')"
  app="$appdir/Bambu — $p.app"; rm -rf "$app"; mkdir -p "$app/Contents/MacOS"
  mkdir -p "$app/Contents/Resources"; cp "$icon_source" "$app/Contents/Resources/bambu.icns"
  printf '%s\n' '#!/bin/bash' 'exec "$HOME/bin/bambu" '"$(printf '%q' "$p")" > "$app/Contents/MacOS/BambuProfile"
  chmod 700 "$app/Contents/MacOS/BambuProfile"
  printf '%s\n' '<?xml version="1.0" encoding="UTF-8"?>' '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">' '<plist version="1.0"><dict>' '<key>CFBundleDisplayName</key><string>Bambu — '"$p"'</string>' '<key>CFBundleExecutable</key><string>BambuProfile</string>' '<key>CFBundleIconFile</key><string>bambu.icns</string>' '<key>CFBundleIdentifier</key><string>local.team.bambu-profile.'"$identifier"'</string>' '<key>CFBundleName</key><string>Bambu — '"$p"'</string>' '<key>CFBundlePackageType</key><string>APPL</string>' '<key>CFBundleShortVersionString</key><string>1.2</string>' '<key>CFBundleVersion</key><string>1.2</string>' '</dict></plist>' > "$app/Contents/Info.plist"
  xattr -cr "$app"; codesign --force --sign - "$app" >/dev/null
  echo "Made $app"
}
install_script() {
  local self backup script_dir icon_source icon_dest
  self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"; mkdir -p "$HOME/bin"
  cp "$self" "$HOME/bin/bambu"; chmod 700 "$HOME/bin/bambu"
  script_dir="$(dirname "$self")"; icon_source="$script_dir/bambu.icns"; icon_dest="$HOME/.local/share/bambu-profile-switcher/bambu.icns"
  [ -f "$icon_source" ] || die "Bundled Bambu launcher icon is missing."
  mkdir -p "$(dirname "$icon_dest")"; cp "$icon_source" "$icon_dest"; chmod 600 "$icon_dest"
  case ":$PATH:" in *":$HOME/bin:"*) ;; *)
    [ -f "$HOME/.zshrc" ] && { backup="$HOME/.zshrc.bambu-switcher-backup.$(date +%Y%m%d%H%M%S)"; cp "$HOME/.zshrc" "$backup"; echo "Backed up ~/.zshrc to $(basename "$backup")"; }
    printf '\n# Added by Bambu account switcher\nexport PATH="$HOME/bin:$PATH"\n' >> "$HOME/.zshrc";; esac
}
init_first() {
  local p="$1"; require_profile "$p"; mkdir -p "$ROOT" "$SESS"
  if [ -e "$LINK" ] && [ ! -L "$LINK" ]; then [ ! -e "$ROOT/$p" ] || die "Profile already exists: $p"; mv "$LINK" "$ROOT/$p"; ln -s "$ROOT/$p" "$LINK"
  elif [ ! -e "$LINK" ]; then mkdir -p "$ROOT/$p"; ln -s "$ROOT/$p" "$LINK"; else echo "Already set up. Current profile: $(current)"; fi
  echo "First profile ready: $p"
}
setup() {
  echo "Run Bambu Setup.app for the guided setup, or use: bambu --init <name>; bambu --add <name>; bambu --make-app <name>."
}
case "${1:-}" in
  setup|--setup) setup;;
  --init) [ -n "${2:-}" ] || die "Usage: bambu --init <name>"; init_first "$2";;
  --add) [ -n "${2:-}" ] || die "Usage: bambu --add <name>"; require_profile "$2"; mkdir -p "$ROOT" "$SESS"; [ ! -e "$ROOT/$2" ] || die "Profile already exists: $2"; mkdir "$ROOT/$2"; echo "Created profile: $2";;
  --make-app) [ -n "${2:-}" ] || die "Usage: bambu --make-app <name>"; make_dock_app "$2";;
  --status|-s) echo "Current profile: $(current)"; echo "Available: $(list_profiles | tr '\n' ' ')";;
  "") echo "Use: bambu <profile>, bambu --status, or Bambu Setup.app.";;
  *) switch_to "$1";;
esac

# Bambu Studio local-profile switcher for macOS

This is a small private-team utility: click a profile launcher, Bambu Studio is asked to quit, that **local Mac's** Bambu profile is selected, then Bambu Studio reopens. It does not send accounts, cookies, passwords, or profile data anywhere.

## Install

1. Unzip the package without changing its contents.
2. Confirm Bambu Studio is installed in `/Applications/BambuStudio.app` and save any open work.
3. Open **Bambu Setup.app**. If macOS asks, use Finder's right-click **Open** once; this is an internal, ad-hoc-signed utility, not Apple-notarized software.
4. Name the currently active account, add any local profile names, and use the newly created launchers in `~/Applications`.

Each new profile opens logged out on its first launch; sign in once in Bambu Studio. Later switches restore only that Mac's saved session for that local profile.

## Safety behavior

- The switcher requests a normal Bambu Studio quit and waits up to 30 seconds. If it remains open, it aborts without changing profiles.
- It saves the outgoing session before the link changes, prepares the incoming session before removing the live one, and restores the previous profile link if a replacement fails.
- Profile names are deliberately restricted to simple names (letters, numbers, spaces, dot, underscore, dash); they cannot form paths.
- The existing Bambu Studio data directory is adopted as the first profile without deleting it. The installer backs up `.zshrc` before adding `~/bin` to the path.

## Requirements and limits

- macOS and a normal Bambu Studio installation in `/Applications`. An advanced user can point to another app location with `BAMBU_STUDIO_APP`.
- This is for trusted people using their own Macs. Do not copy profile folders or the hidden session backups between people.
- The app is ad-hoc signed to keep its resource seal coherent, but it is **not** Developer-ID signed or notarized. Teammates must use Finder's explicit Open flow; do not bypass macOS security settings or run shell commands from untrusted copies.

## Verify before sharing

Run `codesign --verify --deep --strict --verbose "Bambu Setup.app"` from this folder. You can also inspect the contents with `unzip -l`; the release contains no `._*` AppleDouble metadata files.

## Finding the apps

After unzipping this download, **Bambu Setup.app** is immediately at the top level. Open it from Finder to create the profile launchers.

The setup app and the generated profile launchers become Command-Space searchable only after they are in `~/Applications` or `/Applications` and Spotlight indexing is enabled. This package cannot override a Mac where Spotlight indexing is disabled.
